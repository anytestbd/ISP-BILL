CREATE TABLE IF NOT EXISTS "User" ("id" text PRIMARY KEY, "email" text UNIQUE NOT NULL, "password" text NOT NULL, "name" text, "createdAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS "UserData" ("id" text PRIMARY KEY, "userId" text UNIQUE NOT NULL REFERENCES "User"("id") ON DELETE CASCADE, "payload" jsonb NOT NULL, "updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS "Settings" ("id" text PRIMARY KEY, "userId" text UNIQUE NOT NULL REFERENCES "User"("id") ON DELETE CASCADE, "businessName" text NOT NULL DEFAULT 'HISAB WEB', "sheetWebhook" text, "updatedAt" timestamptz NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS "User_email_idx" ON "User"("email");
