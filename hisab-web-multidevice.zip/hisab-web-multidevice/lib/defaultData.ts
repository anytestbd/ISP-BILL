export type Customer={id:string;clientCode:string;name:string;phone:string;address:string;area:string;packageName:string;monthlyFee:number;mbps:number;ipAddress:string;connectionType:string;status:'Active'|'Inactive';billingDay:number;advance:number;due:number;lastPayment?:string};
export type Payment={id:string;receiptNo:string;customerId:string;month:string;amount:number;discount:number;previousDue:number;remainingDue:number;method:string;trxId:string;date:string};
export type Expense={id:string;voucherNo:string;category:string;title:string;amount:number;method:string;spentBy:string;note?:string;date:string};
export type Income={id:string;voucherNo:string;category:string;title:string;amount:number;method:string;collectedBy:string;note?:string;date:string};
export type PackageItem={id:string;name:string;speed:number;price:number;systemFee:number;profit:number;status:boolean};
export type Category={id:string;name:string;type:'INCOME'|'EXPENSE';status:boolean};
export type AppData={customers:Customer[];payments:Payment[];expenses:Expense[];incomes:Income[];packages:PackageItem[];categories:Category[]};
export const emptyData:AppData={customers:[],payments:[],expenses:[],incomes:[],packages:[],categories:[]};
export function today(){return new Date().toISOString().slice(0,10)}
export function money(n:number){return new Intl.NumberFormat('en-BD',{style:'currency',currency:'BDT',maximumFractionDigits:0}).format(n||0)}
export function uid(p:string){return p+'-'+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
