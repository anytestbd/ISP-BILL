import {cookies} from 'next/headers';
import {jwtVerify,SignJWT} from 'jose';
const secret=new TextEncoder().encode(process.env.AUTH_SECRET||'change-me-in-production');
export async function setSession(userId:string){const token=await new SignJWT({uid:userId}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('30d').sign(secret);(await cookies()).set('hisab_session',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:60*60*24*30});}
export async function getUserId(){try{const token=(await cookies()).get('hisab_session')?.value;if(!token)return null;const {payload}=await jwtVerify(token,secret);return typeof payload.uid==='string'?payload.uid:null;}catch{return null}}
export async function clearSession(){(await cookies()).delete('hisab_session');}
