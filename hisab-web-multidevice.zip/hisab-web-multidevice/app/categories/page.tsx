import {Categories} from '../../components/ClientApp'; export default function Page(){return <Categories/>}
