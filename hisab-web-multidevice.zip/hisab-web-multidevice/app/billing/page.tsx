import {Billing} from '../../components/ClientApp'; export default function Page(){return <Billing/>}
