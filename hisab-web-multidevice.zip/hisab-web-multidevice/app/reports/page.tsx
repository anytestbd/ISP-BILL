import {Reports} from '../../components/ClientApp'; export default function Page(){return <Reports/>}
