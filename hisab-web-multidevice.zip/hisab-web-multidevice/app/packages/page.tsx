import {Packages} from '../../components/ClientApp'; export default function Page(){return <Packages/>}
