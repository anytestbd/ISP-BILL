import {Settings} from '../../components/ClientApp'; export default function Page(){return <Settings/>}
