import {Customers} from '../../components/ClientApp'; export default function Page(){return <Customers/>}
