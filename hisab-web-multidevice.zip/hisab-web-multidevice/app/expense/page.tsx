import {Finance} from '../../components/ClientApp'; export default function Page(){return <Finance type="expense"/>}
